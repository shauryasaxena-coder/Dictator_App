plugins {
    // placeholder
}
allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
